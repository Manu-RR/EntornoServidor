<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
 pageEncoding="ISO-8859-1"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html><body>
<h1>Gesti�n de Empleados</h1>
<ul>
  <li><a href="empresa?accion=listar">Mostrar Empleados</a></li>
  <li><a href="empresa?accion=sueldo">Mostrar Salario por DNI</a></li>
  <li><a href="empresa?accion=modificar">Modificar Datos</a></li>
</ul>
</body></html>
