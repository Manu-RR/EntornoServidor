package com.aprendec.front.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface Action {
    /**
     * Ejecuta la acción y devuelve la vista
     */
    String execute(HttpServletRequest request, HttpServletResponse response) throws Exception;
}
