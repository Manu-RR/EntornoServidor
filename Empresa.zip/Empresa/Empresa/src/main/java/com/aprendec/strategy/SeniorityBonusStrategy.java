package com.aprendec.strategy;

import com.aprendec.dao.EmpleadoDAO;
import com.aprendec.model.Empleado;

public class SeniorityBonusStrategy implements SalaryStrategy {

    @Override
    public double calcular(EmpleadoDAO dao, String dni) throws Exception {
        double base = new BasicSalaryStrategy().calcular(dao, dni);
        try {
            java.lang.reflect.Method m = dao.getClass().getMethod("buscarEmpleadoPorDni", String.class);
            Object obj = m.invoke(dao, dni);
            if (obj != null && obj instanceof Empleado) {
                Empleado e = (Empleado) obj;
                if (e.getAniosTrabajados() > 10) {
                    return base * 1.10;
                }
            }
        } catch (NoSuchMethodException ns) {
            
        }
        return base;
    }
}
