package com.aprendec.front.actions;

import com.aprendec.dao.EmpleadoDAO;
import com.aprendec.factory.DAOFactory;
import com.aprendec.model.Empleado;

import javax.servlet.http.*;

public class ModificarEmpleadoAction implements Action {

    private EmpleadoDAO empleadoDAO = DAOFactory.getEmpleadoDAO();

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // Si op=guardar -> procesar actualización 
        if ("guardar".equals(request.getParameter("op"))) {
            Empleado e = new Empleado();
            e.setDni(request.getParameter("dni"));
            e.setNombre(request.getParameter("nombre"));
            String sexo = request.getParameter("sexo");
            if (sexo != null && sexo.length() > 0) e.setSexo(sexo.charAt(0));
            String categoria = request.getParameter("categoria");
            if (categoria != null && categoria.length() > 0) e.setCategoria(Integer.parseInt(categoria));
            String anyos = request.getParameter("anyos");
            if (anyos != null && anyos.length() > 0) e.setAniosTrabajados(Integer.parseInt(anyos));
            empleadoDAO.actualizarEmpleado(e);
            return "redirect:/empresa?accion=listar";
        }
        return "views/ModificarDatos.jsp";
    }
}
