package com.aprendec.factory;

import com.aprendec.dao.EmpleadoDAO;

public class DAOFactory {

    public static EmpleadoDAO getEmpleadoDAO() {
        return new EmpleadoDAO();
    }
}
