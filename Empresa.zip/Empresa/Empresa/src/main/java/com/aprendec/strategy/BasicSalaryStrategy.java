package com.aprendec.strategy;

import com.aprendec.dao.EmpleadoDAO;
import com.aprendec.model.Empleado;

public class BasicSalaryStrategy implements SalaryStrategy {

    @Override
    public double calcular(EmpleadoDAO dao, String dni) throws Exception {
        // Intentamos obtener un Empleado (si el DAO ofrece ese método), si no, usamos buscarSalarioPorDni
        try {
           
            java.lang.reflect.Method m = dao.getClass().getMethod("buscarEmpleadoPorDni", String.class);
            Object obj = m.invoke(dao, dni);
            if (obj != null && obj instanceof Empleado) {
                Empleado e = (Empleado) obj;
                // cálculo simple por ejemplo: base en Empleado.getCategoria + anyos
                int categoria = e.getCategoria();
                int anyos = e.getAniosTrabajados();
                double base = 1000 + categoria * 200;
                double bonus = anyos * 10;
                return base + bonus;
            }
        } catch (NoSuchMethodException ns) {
            
        }
        
        try {
            java.lang.reflect.Method m2 = dao.getClass().getMethod("buscarSalarioPorDni", String.class);
            Object val = m2.invoke(dao, dni);
            if (val instanceof Number) {
                return ((Number) val).doubleValue();
            }
        } catch (NoSuchMethodException ns2) {
            
        }
        throw new UnsupportedOperationException("El DAO no provee métodos para calcular salario");
    }
}
