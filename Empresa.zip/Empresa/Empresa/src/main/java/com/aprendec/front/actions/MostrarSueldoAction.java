package com.aprendec.front.actions;

import com.aprendec.dao.EmpleadoDAO;
import com.aprendec.factory.DAOFactory;
import com.aprendec.strategy.BasicSalaryStrategy;
import com.aprendec.strategy.SalaryStrategy;

import javax.servlet.http.*;

public class MostrarSueldoAction implements Action {

    private EmpleadoDAO empleadoDAO = DAOFactory.getEmpleadoDAO();
    private SalaryStrategy salaryStrategy = new BasicSalaryStrategy();

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String dni = request.getParameter("dni");
        if (dni != null) {
            double sueldo = salaryStrategy.calcular(empleadoDAO, dni);
            request.setAttribute("dni", dni);
            request.setAttribute("sueldo", sueldo);
        }
        return "views/MostrarSalario.jsp";
    }
}
