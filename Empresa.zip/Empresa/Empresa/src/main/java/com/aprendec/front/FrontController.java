package com.aprendec.front;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.aprendec.front.actions.Action;


public class FrontController extends HttpServlet {
    private Map<String, Action> actions = new HashMap<>();

    @Override
    public void init() throws ServletException {
        
        actions.put("listar", new com.aprendec.front.actions.ListarEmpleadosAction());
        actions.put("sueldo", new com.aprendec.front.actions.MostrarSueldoAction());
        actions.put("modificar", new com.aprendec.front.actions.ModificarEmpleadoAction());
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            process(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("exception", e);
            req.getRequestDispatcher("error.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }

    private void process(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        
        String op = req.getParameter("accion");
        if (op == null) op = req.getParameter("op"); 
        if (op == null) op = "listar";

        Action action = actions.get(op);
        if (action == null) {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND, "Acción no encontrada: " + op);
            return;
        }

        String view = action.execute(req, resp);
        if (view == null) return;
        if (view.startsWith("redirect:")) {
            resp.sendRedirect(req.getContextPath() + view.substring("redirect:".length()));
        } else {
            req.getRequestDispatcher(view).forward(req, resp);
        }
    }
}
