package com.aprendec.strategy;

import com.aprendec.dao.EmpleadoDAO;

public interface SalaryStrategy {
    /**
     * Calcula el salario a partir del DAO y el dni
     */
    double calcular(com.aprendec.dao.EmpleadoDAO dao, String dni) throws Exception;
}
