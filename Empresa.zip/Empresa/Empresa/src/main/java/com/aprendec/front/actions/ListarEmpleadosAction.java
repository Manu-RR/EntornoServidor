package com.aprendec.front.actions;

import com.aprendec.dao.EmpleadoDAO;
import com.aprendec.factory.DAOFactory;
import com.aprendec.model.Empleado;

import javax.servlet.http.*;
import java.util.List;

public class ListarEmpleadosAction implements Action {

    private EmpleadoDAO empleadoDAO = DAOFactory.getEmpleadoDAO();

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<Empleado> lista = empleadoDAO.listarEmpleados();
        request.setAttribute("empleados", lista);
        return "views/MostrarEmpleados.jsp";
    }
}
