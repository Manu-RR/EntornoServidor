window.onload = function() {
    // Hacer una solicitud a la API para obtener la lista de empleados
    fetch('http://localhost:8080/api/empleados')
        .then(response => response.json())
        .then(data => {
            const tableBody = document.querySelector('#empleados-table tbody');
            
            // Iterar sobre los empleados y agregarlos a la tabla
            data.forEach(empleado => {
                // Verificar si 'añosTrabajados' existe, si no, poner "No disponible"
                const anosTrabajados = empleado.aniosTrabajados ? empleado.aniosTrabajados : 'No disponible';

                // Obtener el salario de cada empleado con una nueva solicitud a la API
                fetch(`http://localhost:8080/api/empleados/${empleado.dni}/salario`)
                    .then(response => response.text())  // Cambiar a .text() ya que devuelve un número
                    .then(salario => {
                        // Convertir el salario en un número y manejar la posibilidad de que esté vacío o no disponible
                        const salarioMostrar = salario ? parseFloat(salario).toFixed(2) : 'No disponible';  // Formatear a 2 decimales

                        const row = document.createElement('tr');
                        row.setAttribute('data-dni', empleado.dni);  // Establecer el atributo `data-dni`
                        row.innerHTML = `
                            <td>${empleado.dni}</td>
                            <td>${empleado.nombre}</td>
                            <td>${empleado.sexo}</td>
                            <td>${empleado.categoria}</td>
                            <td>${anosTrabajados}</td> <!-- Mostrar años trabajados -->
                            <td>${salarioMostrar}</td> <!-- Mostrar salario calculado -->
                            <td>
                                <button onclick="mostrarFormularioEdicion('${empleado.dni}')">Editar</button>
                                <button onclick="borrarEmpleado('${empleado.dni}')">Eliminar</button>
                            </td>
                        `;
                        tableBody.appendChild(row);
                    })
                    .catch(error => {
                        console.error('Error al obtener el salario:', error);
                    });
            });
        })
        .catch(error => {
            console.error('Error al cargar los empleados:', error);
        });
};

// Función para buscar un empleado por DNI
function buscarEmpleado() {
    const dni = document.getElementById('dni-search').value;

    if (dni) {
        fetch(`http://localhost:8080/api/empleados/${dni}`)
            .then(response => response.json())
            .then(data => {
                if (data.dni) {
                    alert(`Empleado encontrado: ${data.nombre} - ${data.salario}`);
                } else {
                    alert('Empleado no encontrado');
                }
            })
            .catch(error => alert('Error al buscar el empleado: ' + error));
    } else {
        alert('Por favor ingrese un DNI');
    }
}

// Función para crear un nuevo empleado
function crearEmpleado() {
    const dni = document.getElementById('dni').value;
    const nombre = document.getElementById('nombre').value;
    const sexo = document.getElementById('sexo').value;
    const categoria = document.getElementById('categoria').value;
    const aniosTrabajados = parseInt(document.getElementById('aniosTrabajados').value);  // Cambié "anos" a "anios"

    // Verificar si el campo de años trabajados está vacío
    if (isNaN(aniosTrabajados) || aniosTrabajados <= 0) {
        alert("Por favor, ingrese un número válido de años trabajados.");
        return;
    }

    // Calcular el salario con el método del backend
    fetch(`http://localhost:8080/api/empleados/${dni}/salario?categoria=${categoria}&aniosTrabajados=${aniosTrabajados}`)
        .then(response => response.json())
        .then(salario => {
            const empleado = { dni, nombre, sexo, categoria, aniosTrabajados, salario };

            fetch('http://localhost:8080/api/empleados', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(empleado)
            })
            .then(response => response.json())
            .then(data => {
                alert('Empleado creado: ' + data.nombre);
                location.reload(); // Recarga la página para mostrar el nuevo empleado
            })
            .catch(error => alert('Error al crear el empleado: ' + error));
        })
        .catch(error => alert('Error al calcular el salario: ' + error));
}

// Función para editar un empleado
function mostrarFormularioEdicion(dni) {
    fetch(`http://localhost:8080/api/empleados/${dni}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById('edit-dni').value = data.dni;
            document.getElementById('edit-nombre').value = data.nombre;
            document.getElementById('edit-sexo').value = data.sexo;
            document.getElementById('edit-categoria').value = data.categoria;
            document.getElementById('edit-aniosTrabajados').value = data.aniosTrabajados;
            document.getElementById('edit-container').style.display = 'block'; // Mostrar el formulario
        })
        .catch(error => console.error('Error al cargar los datos del empleado:', error));
}

// Función para guardar los cambios de edición de un empleado
function editarEmpleado() {
    const dni = document.getElementById('edit-dni').value;
    const nombre = document.getElementById('edit-nombre').value;
    const sexo = document.getElementById('edit-sexo').value;
    const categoria = document.getElementById('edit-categoria').value;
    const aniosTrabajados = parseInt(document.getElementById('edit-aniosTrabajados').value);  // Cambié "anos" a "anios"

    // Verificar si el campo de años trabajados está vacío
    if (isNaN(aniosTrabajados) || aniosTrabajados <= 0) {
        alert("Por favor, ingrese un número válido de años trabajados.");
        return;
    }

    const empleado = { dni, nombre, sexo, categoria, aniosTrabajados };

    fetch(`http://localhost:8080/api/empleados/${dni}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(empleado)
    })
    .then(response => response.json())
    .then(data => {
        alert('Empleado editado correctamente');
        location.reload(); // Recarga la página para ver los cambios
    })
    .catch(error => alert('Error al editar el empleado: ' + error));
}

// Función para eliminar un empleado por DNI
function borrarEmpleado(dni) {
    if (confirm(`¿Seguro que quieres eliminar al empleado con DNI ${dni}?`)) {
        fetch(`http://localhost:8080/api/empleados/${dni}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            alert(data);

            // Eliminar la fila correspondiente de la tabla sin recargar la página
            const row = document.querySelector(`tr[data-dni="${dni}"]`);
            if (row) {
                row.remove();  // Elimina la fila de la tabla
            }
        })
        .catch(error => alert('Error al eliminar el empleado: ' + error));
    }
}
