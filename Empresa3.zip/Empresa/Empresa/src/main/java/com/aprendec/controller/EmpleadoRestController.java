package com.aprendec.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.aprendec.model.Empleado;
import com.aprendec.service.EmpleadoService;

@RestController
@RequestMapping("/api/empleados")

public class EmpleadoRestController {

    private final EmpleadoService service;

    public EmpleadoRestController(EmpleadoService service) {
        this.service = service;
    }

    
    // LISTAR  
    @GetMapping
    public List<Empleado> listar() {
        return service.listar();
    }

    // OBTENER POR DNI-
    @GetMapping("/{dni}")
    public Empleado buscar(@PathVariable String dni) {
        return service.buscar(dni);
    }


    // CREAR EMPLEADO NUEVO
    @PostMapping
    public Empleado crear(@RequestBody Empleado e) {
        return service.crear(e);
    }


    // EDITAR / MODIFICAR EMPLEADO
    @PutMapping("/{dni}")
    public Empleado modificar(@PathVariable String dni, @RequestBody Empleado datos) {
        return service.modificar(dni, datos);
    }


    // BORRAR EMPLEADO
    @DeleteMapping("/{dni}")
    public String borrar(@PathVariable String dni) {
        service.borrar(dni);
        return "Empleado con DNI " + dni + " eliminado correctamente.";
    }

    // CALCULAR SALARIO  
    @GetMapping("/{dni}/salario")
    public double salario(@PathVariable String dni) {
        return service.calcularSalario(dni);
    }
}
