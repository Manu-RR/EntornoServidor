package com.aprendec.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.aprendec.model.Empleado;
import com.aprendec.repository.EmpleadoRepository;

@Service
public class EmpleadoService {

    private final EmpleadoRepository repo;

    public EmpleadoService(EmpleadoRepository repo) {
        this.repo = repo;
    }

    
    // LISTAR EMPLEADOS
   
    public List<Empleado> listar() {
        return repo.findAll();
    }

  
    // BUSCAR EMPLEADO POR DNI
    
    public Empleado buscar(String dni) {
        return repo.findById(dni)
                .orElseThrow(() -> new RuntimeException("Empleado con DNI " + dni + " no encontrado"));
    }

    
    // CREAR EMPLEADO
    
    public Empleado crear(Empleado e) {
        if (repo.existsById(e.getDni())) {
            throw new RuntimeException("Ya existe un empleado con el DNI " + e.getDni());
        }
        return repo.save(e);
    }

    
    // MODIFICAR EMPLEADO 
    
    public Empleado modificar(String dni, Empleado nuevosDatos) {
        Empleado e = buscar(dni);

        e.setNombre(nuevosDatos.getNombre());
        e.setSexo(nuevosDatos.getSexo());
        e.setCategoria(nuevosDatos.getCategoria());
        e.setAniosTrabajados(nuevosDatos.getAniosTrabajados());

        return repo.save(e);
    }

    
    // BORRAR EMPLEADO
    
    public void borrar(String dni) {
        if (!repo.existsById(dni)) {
            throw new RuntimeException("No se puede borrar. Empleado con DNI " + dni + " no existe.");
        }
        repo.deleteById(dni);
    }

   
    // CALCULAR SALARIO 
    //   sueldo = base(1000) + categoria*200 + años*10

 
    public double calcularSalario(String dni) {
        Empleado e = buscar(dni);

        double base = 1000;
        double plusCategoria = e.getCategoria() * 200;
        double plusAntiguedad = e.getAniosTrabajados() * 10;

        return base + plusCategoria + plusAntiguedad;
    }
}
