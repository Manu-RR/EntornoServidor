package com.companyname.springapp.business.repositories;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.companyname.springapp.business.SpringappBusinessConfig;
import com.companyname.springapp.business.entities.Product;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {SpringappBusinessConfig.class})
public class ProductRepositoryTests {

    @Autowired
    private ProductRepository productRepository;

    @Test
    public void testGetProductList() {
        List<Product> products = (List<Product>) productRepository.findAll();
        assertEquals(3, products.size());
    }
    
    @Test
    public void testSaveProduct() {
        List<Product> products = (List<Product>) productRepository.findAll();

        Product p = products.get(0);
        Double price = p.getPrice();
        p.setPrice(200.12);
        productRepository.save(p);

        List<Product> updatedProducts = (List<Product>) productRepository.findAll();
        Product p2 = updatedProducts.get(0);
        assertEquals(200.12, p2.getPrice());

        // Restoring the original price
        p2.setPrice(price);
        productRepository.save(p2);
    }
}
